#include <draw2d/image.hpp>

#include <memory>
#include <algorithm>

#include <cstdio>
#include <cstring>
#include <cassert>

#include <stb_image.h>

#include <draw2d/surface.hpp>
#include <support/error.hpp>

namespace
{
	struct STBImageRGBA_ : public ImageRGBA
	{
		STBImageRGBA_( Index, Index, std::uint8_t* );
		virtual ~STBImageRGBA_();
	};
}

ImageRGBA::ImageRGBA()
	: mWidth( 0 )
	, mHeight( 0 )
	, mData( nullptr )
{}

ImageRGBA::~ImageRGBA() = default;


std::unique_ptr<ImageRGBA> load_image( char const* aPath )
{
	assert( aPath );

	stbi_set_flip_vertically_on_load( true );

	int w, h, channels;
	stbi_uc* ptr = stbi_load( aPath, &w, &h, &channels, 4 );
	if( !ptr )
		throw Error( "Unable to load image \"{}\"", aPath );

	return std::make_unique<STBImageRGBA_>(
		ImageRGBA::Index(w),
		ImageRGBA::Index(h),
		ptr
	);
}

// Task 1.4
void blit_masked( Surface& aSurface, ImageRGBA const& aImage, Vec2f aPosition )
{
	// TODO: your implementation goes here
}

// Task 2.1
void blit_masked_subregion( Surface& aSurface, ImageRGBA const& aImage, Vec2i aSourceOrigin, Vec2i aSourceSize, Vec2f aPosition )
{
	// TODO: your implementation goes here
}

// Task 2.2
void blit_blend_subregion( Surface& aSurface, ImageRGBA const& aImage, Vec2i aSourceOrigin, Vec2i aSourceSize, Vec2f aPosition )
{
	// TODO: your implementation goes here
}


namespace
{
	STBImageRGBA_::STBImageRGBA_( Index aWidth, Index aHeight, std::uint8_t* aPtr )
	{
		mWidth = aWidth;
		mHeight = aHeight;
		mData = aPtr;
	}

	STBImageRGBA_::~STBImageRGBA_()
	{
		if( mData )
			stbi_image_free( mData );
	}
}
